/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bancoch.controller;

import com.mycompany.bancoch.dao.Conexao;
import com.mycompany.bancoch.dao.PessoaDAO;
import com.mycompany.bancoch.model.Pessoa;
import java.sql.*;

public class PessoaController {
    private PessoaDAO pessoaDAO;

    public PessoaController() {
        pessoaDAO = new PessoaDAO();
    }

    public void inserirPessoa(Pessoa pessoa) throws SQLException {
        pessoaDAO.inserir(pessoa);
    }

    public Pessoa buscarPessoaPorCodigo(int codigo) throws SQLException {
        return pessoaDAO.buscarPorCodigo(codigo);
    }

    public void atualizarPessoa(Pessoa pessoa) throws SQLException {
        pessoaDAO.atualizar(pessoa);
    }

    public void deletarPessoa(int codigo) throws SQLException {
        pessoaDAO.deletar(codigo);
    }
    public int inserirRetornandoCodigo(Pessoa pessoa) throws SQLException {
    String sql = "INSERT INTO Pessoa (nome, telefone, rua, numero, cidade, estado) VALUES (?, ?, ?, ?, ?, ?)";
    int codigoGerado = -1;

    try (Connection conn = Conexao.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

        stmt.setString(1, pessoa.getNome());
        stmt.setString(2, pessoa.getTelefone());
        stmt.setString(3, pessoa.getRua());
        stmt.setString(4, pessoa.getNumero());
        stmt.setString(5, pessoa.getCidade());
        stmt.setString(6, pessoa.getEstado());

        stmt.executeUpdate();

        try (ResultSet rs = stmt.getGeneratedKeys()) {
            if (rs.next()) {
                codigoGerado = rs.getInt(1);
            }
        }
    }
    return codigoGerado;
}

}
