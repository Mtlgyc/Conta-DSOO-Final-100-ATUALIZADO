/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bancoch.controller;

import com.mycompany.bancoch.dao.ContaDAO;
import com.mycompany.bancoch.model.Conta;
import java.sql.SQLException;

public class ContaController {
    private ContaDAO contaDAO;

    public ContaController() {
        contaDAO = new ContaDAO();
    }

    public void inserirConta(Conta conta) throws SQLException {
        contaDAO.inserir(conta);
    }

    public Conta buscarContaPorNumero(String numero) throws SQLException {
        return contaDAO.buscarPorNumero(numero);
    }

    public void atualizarConta(Conta conta) throws SQLException {
        contaDAO.atualizar(conta);
    }

    public void deletarConta(int numero) throws SQLException {
        contaDAO.deletar(numero);
    }
}
