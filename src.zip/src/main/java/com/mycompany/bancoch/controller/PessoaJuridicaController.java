/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bancoch.controller;

import com.mycompany.bancoch.dao.PessoaJuridicaDAO;
import com.mycompany.bancoch.model.PessoaJuridica;
import java.sql.SQLException;

public class PessoaJuridicaController {
    private PessoaJuridicaDAO pessoaJuridicaDAO;

    public PessoaJuridicaController() {
        pessoaJuridicaDAO = new PessoaJuridicaDAO();
    }

    public void inserirPessoaJuridica(PessoaJuridica pj) throws SQLException {
        pessoaJuridicaDAO.inserir(pj);
    }

    public PessoaJuridica buscarPessoaJuridicaPorCodigo(int codigo) throws SQLException {
        return pessoaJuridicaDAO.buscarPorCodigo(codigo);
    }

    public void atualizarPessoaJuridica(PessoaJuridica pj) throws SQLException {
        pessoaJuridicaDAO.atualizar(pj);
    }

    public void deletarPessoaJuridica(int codigo) throws SQLException {
        pessoaJuridicaDAO.deletar(codigo);
    }
}
