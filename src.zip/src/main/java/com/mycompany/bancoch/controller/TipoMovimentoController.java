/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bancoch.controller;

import com.mycompany.bancoch.dao.TipoMovimentoDAO;
import com.mycompany.bancoch.model.TipoMovimento;
import java.sql.SQLException;

public class TipoMovimentoController {
    private TipoMovimentoDAO tipoMovimentoDAO;

    public TipoMovimentoController() {
        tipoMovimentoDAO = new TipoMovimentoDAO();
    }

    public void inserirTipoMovimento(TipoMovimento tipo) throws SQLException {
        tipoMovimentoDAO.inserir(tipo);
    }

    public TipoMovimento buscarTipoMovimentoPorCodigo(int codigo) throws SQLException {
        return tipoMovimentoDAO.buscarPorCodigo(codigo);
    }

    public void atualizarTipoMovimento(TipoMovimento tipo) throws SQLException {
        tipoMovimentoDAO.atualizar(tipo);
    }

    public void deletarTipoMovimento(int codigo) throws SQLException {
        tipoMovimentoDAO.deletar(codigo);
    }
}

