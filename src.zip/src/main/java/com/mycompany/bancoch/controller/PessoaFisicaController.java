/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bancoch.controller;

import com.mycompany.bancoch.dao.PessoaFisicaDAO;
import com.mycompany.bancoch.model.PessoaFisica;
import java.sql.SQLException;

public class PessoaFisicaController {
    private PessoaFisicaDAO pessoaFisicaDAO;

    public PessoaFisicaController() {
        pessoaFisicaDAO = new PessoaFisicaDAO();
    }

    public void inserirPessoaFisica(PessoaFisica pf) throws SQLException {
        pessoaFisicaDAO.inserir(pf);
    }

    public PessoaFisica buscarPessoaFisicaPorCodigo(int codigo) throws SQLException {
        return pessoaFisicaDAO.buscarPorCodigo(codigo);
    }

    public void atualizarPessoaFisica(PessoaFisica pf) throws SQLException {
        pessoaFisicaDAO.atualizar(pf);
    }

    public void deletarPessoaFisica(int codigo) throws SQLException {
        pessoaFisicaDAO.deletar(codigo);
    }
}
