/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bancoch.controller;

import com.mycompany.bancoch.dao.MovimentoDAO;
import com.mycompany.bancoch.model.Movimento;
import java.sql.SQLException;

public class MovimentoController {
    private MovimentoDAO movimentoDAO;

    public MovimentoController() {
        movimentoDAO = new MovimentoDAO();
    }

    public void inserirMovimento(Movimento movimento) throws SQLException {
        movimentoDAO.inserir(movimento);
    }

    public Movimento buscarMovimentoPorNumero(int numero) throws SQLException {
        return movimentoDAO.buscarPorNumero(numero);
    }

    public void atualizarMovimento(Movimento movimento) throws SQLException {
        movimentoDAO.atualizar(movimento);
    }

    public void deletarMovimento(int numero) throws SQLException {
        movimentoDAO.deletar(numero);
    }
}
