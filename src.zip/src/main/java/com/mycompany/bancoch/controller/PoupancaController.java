/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bancoch.controller;

import com.mycompany.bancoch.dao.PoupancaDAO;
import com.mycompany.bancoch.model.Poupanca;
import java.sql.SQLException;

public class PoupancaController {
    private PoupancaDAO poupancaDAO;

    public PoupancaController() {
        poupancaDAO = new PoupancaDAO();
    }

    public void inserirPoupanca(Poupanca poupanca) throws SQLException {
        poupancaDAO.inserir(poupanca);
    }

    public Poupanca buscarPoupancaPorNumero(int numero) throws SQLException {
        return poupancaDAO.buscarPorNumero(numero);
    }

    public void atualizarPoupanca(Poupanca poupanca) throws SQLException {
        poupancaDAO.atualizar(poupanca);
    }

    public void deletarPoupanca(int numero) throws SQLException {
        poupancaDAO.deletar(numero);
    }
}
