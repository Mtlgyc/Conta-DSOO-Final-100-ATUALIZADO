/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bancoch.controller;

import com.mycompany.bancoch.dao.ContaEspecialDAO;
import com.mycompany.bancoch.model.ContaEspecial;
import java.sql.SQLException;

public class ContaEspecialController {
    private ContaEspecialDAO contaEspecialDAO;

    public ContaEspecialController() {
        contaEspecialDAO = new ContaEspecialDAO();
    }

    public void inserirContaEspecial(ContaEspecial ce) throws SQLException {
        contaEspecialDAO.inserir(ce);
    }

    public ContaEspecial buscarContaEspecialPorNumero(int numero) throws SQLException {
        return contaEspecialDAO.buscarPorNumero(numero);
    }

    public void atualizarContaEspecial(ContaEspecial ce) throws SQLException {
        contaEspecialDAO.atualizar(ce);
    }

    public void deletarContaEspecial(int numero) throws SQLException {
        contaEspecialDAO.deletar(numero);
    }
}
