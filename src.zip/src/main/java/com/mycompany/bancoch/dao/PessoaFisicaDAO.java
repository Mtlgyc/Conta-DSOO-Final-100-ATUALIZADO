/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bancoch.dao;

import com.mycompany.bancoch.model.PessoaFisica;
import com.mycompany.bancoch.dao.Conexao;
import java.sql.*;

public class PessoaFisicaDAO {

    public void inserir(PessoaFisica pf) throws SQLException {
        String sqlPessoa = "INSERT INTO Pessoa (codigo, nome, telefone, rua, numero, cidade, estado) VALUES (?, ?, ?, ?, ?, ?, ?)";
        String sqlPF = "INSERT INTO PessoaFisica (codigo, rg, cpf) VALUES (?, ?, ?)";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement psPessoa = conn.prepareStatement(sqlPessoa);
             PreparedStatement psPF = conn.prepareStatement(sqlPF)) {

            psPessoa.setInt(1, pf.getCodigo());
            psPessoa.setString(2, pf.getNome());
            psPessoa.setString(3, pf.getTelefone());
            psPessoa.setString(4, pf.getRua());
            psPessoa.setString(5, pf.getNumero());
            psPessoa.setString(6, pf.getCidade());
            psPessoa.setString(7, pf.getEstado());
            psPessoa.executeUpdate();

            psPF.setInt(1, pf.getCodigo());
            psPF.setString(2, pf.getRg());
            psPF.setString(3, pf.getCpf());
            psPF.executeUpdate();
        }
    }

    public PessoaFisica buscarPorCodigo(int codigo) throws SQLException {
        String sql = "SELECT p.*, pf.rg, pf.cpf FROM Pessoa p JOIN PessoaFisica pf ON p.codigo = pf.codigo WHERE p.codigo = ?";
        PessoaFisica pf = null;

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, codigo);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    pf = new PessoaFisica();
                    pf.setCodigo(rs.getInt("codigo"));
                    pf.setNome(rs.getString("nome"));
                    pf.setTelefone(rs.getString("telefone"));
                    pf.setRua(rs.getString("rua"));
                    pf.setNumero(rs.getString("numero"));
                    pf.setCidade(rs.getString("cidade"));
                    pf.setEstado(rs.getString("estado"));
                    pf.setRg(rs.getString("rg"));
                    pf.setCpf(rs.getString("cpf"));
                }
            }
        }
        return pf;
    }

    public void atualizar(PessoaFisica pf) throws SQLException {
        String sqlPessoa = "UPDATE Pessoa SET nome=?, telefone=?, rua=?, numero=?, cidade=?, estado=? WHERE codigo=?";
        String sqlPF = "UPDATE PessoaFisica SET rg=?, cpf=? WHERE codigo=?";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement psPessoa = conn.prepareStatement(sqlPessoa);
             PreparedStatement psPF = conn.prepareStatement(sqlPF)) {

            psPessoa.setString(1, pf.getNome());
            psPessoa.setString(2, pf.getTelefone());
            psPessoa.setString(3, pf.getRua());
            psPessoa.setString(4, pf.getNumero());
            psPessoa.setString(5, pf.getCidade());
            psPessoa.setString(6, pf.getEstado());
            psPessoa.setInt(7, pf.getCodigo());
            psPessoa.executeUpdate();

            psPF.setString(1, pf.getRg());
            psPF.setString(2, pf.getCpf());
            psPF.setInt(3, pf.getCodigo());
            psPF.executeUpdate();
        }
    }

    public void deletar(int codigo) throws SQLException {
        String sqlPF = "DELETE FROM PessoaFisica WHERE codigo=?";
        String sqlPessoa = "DELETE FROM Pessoa WHERE codigo=?";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement psPF = conn.prepareStatement(sqlPF);
             PreparedStatement psPessoa = conn.prepareStatement(sqlPessoa)) {

            psPF.setInt(1, codigo);
            psPF.executeUpdate();

            psPessoa.setInt(1, codigo);
            psPessoa.executeUpdate();
        }
    }
}
