/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bancoch.dao;

import com.mycompany.bancoch.model.PessoaJuridica;
import com.mycompany.bancoch.dao.Conexao;
import java.sql.*;

public class PessoaJuridicaDAO {

    public void inserir(PessoaJuridica pj) throws SQLException {
        String sqlPessoa = "INSERT INTO Pessoa (codigo, nome, telefone, rua, numero, cidade, estado) VALUES (?, ?, ?, ?, ?, ?, ?)";
        String sqlPJ = "INSERT INTO PessoaJuridica (codigo, cnpj) VALUES (?, ?)";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement psPessoa = conn.prepareStatement(sqlPessoa);
             PreparedStatement psPJ = conn.prepareStatement(sqlPJ)) {

            psPessoa.setInt(1, pj.getCodigo());
            psPessoa.setString(2, pj.getNome());
            psPessoa.setString(3, pj.getTelefone());
            psPessoa.setString(4, pj.getRua());
            psPessoa.setString(5, pj.getNumero());
            psPessoa.setString(6, pj.getCidade());
            psPessoa.setString(7, pj.getEstado());
            psPessoa.executeUpdate();

            psPJ.setInt(1, pj.getCodigo());
            psPJ.setString(2, pj.getCnpj());
            psPJ.executeUpdate();
        }
    }

    public PessoaJuridica buscarPorCodigo(int codigo) throws SQLException {
        String sql = "SELECT p.*, pj.cnpj FROM Pessoa p JOIN PessoaJuridica pj ON p.codigo = pj.codigo WHERE p.codigo = ?";
        PessoaJuridica pj = null;

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, codigo);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    pj = new PessoaJuridica();
                    pj.setCodigo(rs.getInt("codigo"));
                    pj.setNome(rs.getString("nome"));
                    pj.setTelefone(rs.getString("telefone"));
                    pj.setRua(rs.getString("rua"));
                    pj.setNumero(rs.getString("numero"));
                    pj.setCidade(rs.getString("cidade"));
                    pj.setEstado(rs.getString("estado"));
                    pj.setCnpj(rs.getString("cnpj"));
                }
            }
        }
        return pj;
    }

    public void atualizar(PessoaJuridica pj) throws SQLException {
        String sqlPessoa = "UPDATE Pessoa SET nome=?, telefone=?, rua=?, numero=?, cidade=?, estado=? WHERE codigo=?";
        String sqlPJ = "UPDATE PessoaJuridica SET cnpj=? WHERE codigo=?";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement psPessoa = conn.prepareStatement(sqlPessoa);
             PreparedStatement psPJ = conn.prepareStatement(sqlPJ)) {

            psPessoa.setString(1, pj.getNome());
            psPessoa.setString(2, pj.getTelefone());
            psPessoa.setString(3, pj.getRua());
            psPessoa.setString(4, pj.getNumero());
            psPessoa.setString(5, pj.getCidade());
            psPessoa.setString(6, pj.getEstado());
            psPessoa.setInt(7, pj.getCodigo());
            psPessoa.executeUpdate();

            psPJ.setString(1, pj.getCnpj());
            psPJ.setInt(2, pj.getCodigo());
            psPJ.executeUpdate();
        }
    }

    public void deletar(int codigo) throws SQLException {
        String sqlPJ = "DELETE FROM PessoaJuridica WHERE codigo=?";
        String sqlPessoa = "DELETE FROM Pessoa WHERE codigo=?";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement psPJ = conn.prepareStatement(sqlPJ);
             PreparedStatement psPessoa = conn.prepareStatement(sqlPessoa)) {

            psPJ.setInt(1, codigo);
            psPJ.executeUpdate();

            psPessoa.setInt(1, codigo);
            psPessoa.executeUpdate();
        }
    }
}

