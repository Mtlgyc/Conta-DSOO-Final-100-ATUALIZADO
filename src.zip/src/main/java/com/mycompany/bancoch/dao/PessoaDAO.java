/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bancoch.dao;
import com.mycompany.bancoch.model.Pessoa;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class PessoaDAO {

    public void inserir(Pessoa pessoa) throws SQLException {
        String sql = "INSERT INTO Pessoa (codigo, nome, telefone, rua, numero, cidade, estado) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            stmt.setInt(1, pessoa.getCodigo());
            stmt.setString(2, pessoa.getNome());
            stmt.setString(3, pessoa.getTelefone());
            stmt.setString(4, pessoa.getRua());
            stmt.setString(5, pessoa.getNumero());
            stmt.setString(6, pessoa.getCidade());
            stmt.setString(7, pessoa.getEstado());

            stmt.executeUpdate();
        }
    }

    public Pessoa buscarPorCodigo(int codigo) throws SQLException {
        String sql = "SELECT * FROM Pessoa WHERE codigo = ?";
        Pessoa pessoa = null;
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            stmt.setInt(1, codigo);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    pessoa = new Pessoa();
                    pessoa.setCodigo(rs.getInt("codigo"));
                    pessoa.setNome(rs.getString("nome"));
                    pessoa.setTelefone(rs.getString("telefone"));
                    pessoa.setRua(rs.getString("rua"));
                    pessoa.setNumero(rs.getString("numero"));
                    pessoa.setCidade(rs.getString("cidade"));
                    pessoa.setEstado(rs.getString("estado"));
                }
            }
        }
        return pessoa;
    }

    public void atualizar(Pessoa pessoa) throws SQLException {
        String sql = "UPDATE Pessoa SET nome = ?, telefone = ?, rua = ?, numero = ?, cidade = ?, estado = ? WHERE codigo = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            stmt.setString(1, pessoa.getNome());
            stmt.setString(2, pessoa.getTelefone());
            stmt.setString(3, pessoa.getRua());
            stmt.setString(4, pessoa.getNumero());
            stmt.setString(5, pessoa.getCidade());
            stmt.setString(6, pessoa.getEstado());
            stmt.setInt(7, pessoa.getCodigo());

            stmt.executeUpdate();
        }
    }

    public void deletar(int codigo) throws SQLException {
        String sql = "DELETE FROM Pessoa WHERE codigo = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            stmt.setInt(1, codigo);
            stmt.executeUpdate();
        }
    }
}
