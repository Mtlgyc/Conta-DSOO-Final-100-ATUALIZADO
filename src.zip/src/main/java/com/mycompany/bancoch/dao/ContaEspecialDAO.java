/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bancoch.dao;

import com.mycompany.bancoch.model.ContaEspecial;
import com.mycompany.bancoch.dao.Conexao;
import java.sql.*;

public class ContaEspecialDAO {

    public void inserir(ContaEspecial ce) throws SQLException {
        // Inserir na tabela Conta
        ContaDAO contaDAO = new ContaDAO();
        contaDAO.inserir(ce);

        // Inserir na tabela ContaEspecial
        String sql = "INSERT INTO ContaEspecial (numero, limite) VALUES (?, ?)";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, ce.getNumero());
            stmt.setDouble(2, ce.getLimite());

            stmt.executeUpdate();
        }
    }

    public ContaEspecial buscarPorNumero(int numero) throws SQLException {
        String sql = "SELECT c.*, ce.limite FROM Conta c JOIN ContaEspecial ce ON c.numero = ce.numero WHERE c.numero = ?";
        ContaEspecial ce = null;

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, numero);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    ce = new ContaEspecial();
                    ce.setNumero(rs.getInt("numero"));
                    ce.setDataAbertura(rs.getDate("data_abertura"));
                    ce.setDataFechamento(rs.getDate("data_fechamento"));
                    ce.setSenha(rs.getString("senha"));
                    ce.setSaldo(rs.getDouble("saldo"));
                    ce.setCodigoPessoa(rs.getInt("codigo_pessoa"));
                    ce.setLimite(rs.getDouble("limite"));
                }
            }
        }
        return ce;
    }

    public void atualizar(ContaEspecial ce) throws SQLException {
        ContaDAO contaDAO = new ContaDAO();
        contaDAO.atualizar(ce);

        String sql = "UPDATE ContaEspecial SET limite=? WHERE numero=?";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setDouble(1, ce.getLimite());
            stmt.setInt(2, ce.getNumero());

            stmt.executeUpdate();
        }
    }

    public void deletar(int numero) throws SQLException {
        String sqlCE = "DELETE FROM ContaEspecial WHERE numero=?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sqlCE)) {
            stmt.setInt(1, numero);
            stmt.executeUpdate();
        }

        ContaDAO contaDAO = new ContaDAO();
        contaDAO.deletar(numero);
    }
}

