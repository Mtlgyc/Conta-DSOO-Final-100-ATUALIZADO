/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bancoch.dao;

import com.mycompany.bancoch.model.Poupanca;
import com.mycompany.bancoch.dao.Conexao;
import java.sql.*;

public class PoupancaDAO {

    public void inserir(Poupanca p) throws SQLException {
        // Inserir na tabela Conta
        ContaDAO contaDAO = new ContaDAO();
        contaDAO.inserir(p);

        // Inserir na tabela Poupanca
        String sql = "INSERT INTO Poupanca (numero, data_aniversario) VALUES (?, ?)";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, p.getNumero());
            stmt.setDate(2, new java.sql.Date(p.getDataAniversario().getTime()));

            stmt.executeUpdate();
        }
    }

    public Poupanca buscarPorNumero(int numero) throws SQLException {
        String sql = "SELECT c.*, p.data_aniversario FROM Conta c JOIN Poupanca p ON c.numero = p.numero WHERE c.numero = ?";
        Poupanca poupanca = null;

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, numero);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    poupanca = new Poupanca();
                    poupanca.setNumero(rs.getInt("numero"));
                    poupanca.setDataAbertura(rs.getDate("data_abertura"));
                    poupanca.setDataFechamento(rs.getDate("data_fechamento"));
                    poupanca.setSenha(rs.getString("senha"));
                    poupanca.setSaldo(rs.getDouble("saldo"));
                    poupanca.setCodigoPessoa(rs.getInt("codigo_pessoa"));
                    poupanca.setDataAniversario(rs.getDate("data_aniversario"));
                }
            }
        }
        return poupanca;
    }

    public void atualizar(Poupanca p) throws SQLException {
        ContaDAO contaDAO = new ContaDAO();
        contaDAO.atualizar(p);

        String sql = "UPDATE Poupanca SET data_aniversario=? WHERE numero=?";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setDate(1, new java.sql.Date(p.getDataAniversario().getTime()));
            stmt.setInt(2, p.getNumero());

            stmt.executeUpdate();
        }
    }

    public void deletar(int numero) throws SQLException {
        String sqlPoup = "DELETE FROM Poupanca WHERE numero=?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sqlPoup)) {
            stmt.setInt(1, numero);
            stmt.executeUpdate();
        }

        ContaDAO contaDAO = new ContaDAO();
        contaDAO.deletar(numero);
    }
}


