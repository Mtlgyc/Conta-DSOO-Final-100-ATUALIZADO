/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bancoch.dao;

import com.mycompany.bancoch.model.Movimento;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.sql.Time;

public class MovimentoDAO {

    public void inserir(Movimento mov) throws SQLException {
        String sql = "INSERT INTO Movimento (numero, hora, data, valor, numero_conta, codigo_tipo) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, mov.getNumero());
            stmt.setTime(2, mov.getHora());
            stmt.setDate(3, new Date(mov.getData().getTime()));
            stmt.setDouble(4, mov.getValor());
            stmt.setInt(5, mov.getNumeroConta());
            stmt.setInt(6, mov.getCodigoTipo());

            stmt.executeUpdate();
        }
    }

    public Movimento buscarPorNumero(int numero) throws SQLException {
        String sql = "SELECT * FROM Movimento WHERE numero = ?";
        Movimento mov = null;
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, numero);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    mov = new Movimento();
                    mov.setNumero(rs.getInt("numero"));
                    mov.setHora(rs.getTime("hora"));
                    mov.setData(rs.getDate("data"));
                    mov.setValor(rs.getDouble("valor"));
                    mov.setNumeroConta(rs.getInt("numero_conta"));
                    mov.setCodigoTipo(rs.getInt("codigo_tipo"));
                }
            }
        }
        return mov;
    }

    public void atualizar(Movimento mov) throws SQLException {
        String sql = "UPDATE Movimento SET hora = ?, data = ?, valor = ?, numero_conta = ?, codigo_tipo = ? WHERE numero = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setTime(1, mov.getHora());
            stmt.setDate(2, new Date(mov.getData().getTime()));
            stmt.setDouble(3, mov.getValor());
            stmt.setInt(4, mov.getNumeroConta());
            stmt.setInt(5, mov.getCodigoTipo());
            stmt.setInt(6, mov.getNumero());

            stmt.executeUpdate();
        }
    }

    public void deletar(int numero) throws SQLException {
        String sql = "DELETE FROM Movimento WHERE numero = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, numero);
            stmt.executeUpdate();
        }
    }
}
