/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bancoch.dao;

import com.mycompany.bancoch.model.TipoMovimento;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TipoMovimentoDAO {

    public void inserir(TipoMovimento tipo) throws SQLException {
        String sql = "INSERT INTO TipoMovimento (codigo, nome) VALUES (?, ?)";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, tipo.getCodigo());
            stmt.setString(2, tipo.getNome());

            stmt.executeUpdate();
        }
    }

    public TipoMovimento buscarPorCodigo(int codigo) throws SQLException {
        String sql = "SELECT * FROM TipoMovimento WHERE codigo = ?";
        TipoMovimento tipo = null;
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, codigo);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    tipo = new TipoMovimento();
                    tipo.setCodigo(rs.getInt("codigo"));
                    tipo.setNome(rs.getString("nome"));
                }
            }
        }
        return tipo;
    }

    public void atualizar(TipoMovimento tipo) throws SQLException {
        String sql = "UPDATE TipoMovimento SET nome = ? WHERE codigo = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, tipo.getNome());
            stmt.setInt(2, tipo.getCodigo());

            stmt.executeUpdate();
        }
    }

    public void deletar(int codigo) throws SQLException {
        String sql = "DELETE FROM TipoMovimento WHERE codigo = ?";
        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, codigo);
            stmt.executeUpdate();
        }
    }
}

