/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bancoch.dao;

import com.mycompany.bancoch.model.Conta;
import com.mycompany.bancoch.dao.Conexao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ContaDAO {

    public void inserir(Conta conta) throws SQLException {
        String sql = "INSERT INTO Conta (numero, data_abertura, data_fechamento, senha, saldo, codigo_pessoa) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, conta.getNumero());
            stmt.setDate(2, new java.sql.Date(conta.getDataAbertura().getTime()));
            if (conta.getDataFechamento() != null) {
                stmt.setDate(3, new java.sql.Date(conta.getDataFechamento().getTime()));
            } else {
                stmt.setNull(3, Types.DATE);
            }
            stmt.setString(4, conta.getSenha());
            stmt.setDouble(5, conta.getSaldo());
            stmt.setInt(6, conta.getCodigoPessoa());

            stmt.executeUpdate();
        }
    }

    public Conta buscarPorNumero(String numero) throws SQLException {
        String sql = "SELECT * FROM Conta WHERE numero = ?";
        Conta conta = null;

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, Integer.parseInt(numero));
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    conta = new Conta();
                    conta.setNumero(rs.getInt("numero"));
                    conta.setDataAbertura(rs.getDate("data_abertura"));
                    conta.setDataFechamento(rs.getDate("data_fechamento"));
                    conta.setSenha(rs.getString("senha"));
                    conta.setSaldo(rs.getDouble("saldo"));
                    conta.setCodigoPessoa(rs.getInt("codigo_pessoa"));
                }
            }
        }
        return conta;
    }

    public void atualizar(Conta conta) throws SQLException {
        String sql = "UPDATE Conta SET data_abertura=?, data_fechamento=?, senha=?, saldo=?, codigo_pessoa=? WHERE numero=?";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setDate(1, new java.sql.Date(conta.getDataAbertura().getTime()));
            if (conta.getDataFechamento() != null) {
                stmt.setDate(2, new java.sql.Date(conta.getDataFechamento().getTime()));
            } else {
                stmt.setNull(2, Types.DATE);
            }
            stmt.setString(3, conta.getSenha());
            stmt.setDouble(4, conta.getSaldo());
            stmt.setInt(5, conta.getCodigoPessoa());
            stmt.setInt(6, conta.getNumero());

            stmt.executeUpdate();
        }
    }

    public void deletar(int numero) throws SQLException {
        String sql = "DELETE FROM Conta WHERE numero=?";

        try (Connection conn = Conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, numero);
            stmt.executeUpdate();
        }
    }
}
